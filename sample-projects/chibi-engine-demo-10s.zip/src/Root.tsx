import React from 'react';
import { Composition } from 'remotion';
import { Video } from './Video';

export const Root: React.FC = () => {
  return (
    <Composition
      id="ChibiEngineDemo10s"
      component={Video}
      durationInFrames={300}
      fps={30}
      width={1920}
      height={1080}
    />
  );
};
